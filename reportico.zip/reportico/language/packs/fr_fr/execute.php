<?php
$locale_arr = array (
"language" => "French",
"template" => array (
// Maintenance Buttons
		"T_GO_BACK" => "Retour",
		"T_NO_DATA_FOUND" => "Aucune donnée n'a été trouvé correspondant à vos critères",
		"T_INFORMATION" => "De l'information",
		"T_UNABLE_TO_CONTINUE" => "Impossible de continuer",
        "T_GO_REFRESH" => "Rafraîchir",
        "T_GO_PRINT" => "Imprimer",
)
);
?>
