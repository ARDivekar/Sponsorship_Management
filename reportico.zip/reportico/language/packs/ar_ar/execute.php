<?php
$locale_arr = array (
"language" => "English",
"template" => array (
        "T_GO_BACK" => "عودة",
        "T_NO_DATA_FOUND" => "تم العثور على أية بيانات مطابقة للمعايير الخاصة بك",
        "T_UNABLE_TO_CONTINUE" => "غير قادر على الاستمرار",
        "T_INFORMATION" => "معلومات",
        "T_GO_REFRESH" => "تحديث",
        "T_GO_PRINT" => "طباعة",
        )
);
?>
