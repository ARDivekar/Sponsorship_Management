<?php

$locale_arr = array (
    "template" => array (
        "T_en_gb" => "English (UK)",
        "T_en_us" => "English (US)",
        "T_es_es" => "Spanish",
        "T_fr_fr" => "French",
        "T_it_it" => "Italian",
        "T_ar_ar" => "Arabic",
        "T_zh_cn" => "Chinese (Simplified)",
        ),
    );

?>
